namespace Departments;

class RenewalDepartment
{
    public void OnPolicyRenewed()
    {
        Console.WriteLine("Renewal processed.");
    }
}